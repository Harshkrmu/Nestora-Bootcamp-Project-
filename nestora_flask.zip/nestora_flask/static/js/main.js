/* ============================================================
   Nestora dashboard — talks to the Flask API, Matplotlib images
   are just <img> tags pointed at server chart endpoints.
   ============================================================ */

function toast(msg){
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(window._toastT);
  window._toastT = setTimeout(()=>t.classList.remove("show"), 2600);
}

function switchTab(tab){
  document.querySelectorAll(".sidenav button").forEach(b=>b.classList.toggle("active", b.dataset.tab===tab));
  document.querySelectorAll(".tabview").forEach(t=>t.classList.remove("active"));
  document.getElementById("tab-"+tab).classList.add("active");
  if(tab === "hostel") renderHostels();
  if(tab === "roommate") renderRoommates();
}

function fmtHour(v){
  v = parseInt(v);
  const h = v % 24;
  let disp = h % 12; if(disp === 0) disp = 12;
  return disp + " " + (h < 12 ? "AM" : "PM");
}
function syncRange(inputId, outId, fmt){
  const v = document.getElementById(inputId).value;
  document.getElementById(outId).textContent = fmt ? fmt(v) : v;
}

/* refresh dashboard chart <img> tags with a cache-busting query param */
function refreshCharts(){
  const t = Date.now();
  const map = {imgSleep:"/api/charts/sleep.png", imgHobbies:"/api/charts/hobbies.png",
               imgStudy:"/api/charts/study.png", imgGauge:"/api/charts/gauge.png"};
  Object.entries(map).forEach(([id, url])=>{
    const el = document.getElementById(id);
    if(el) el.src = url + "?v=" + t;
  });
}

/* ============================================================
   PREFERENCES
   ============================================================ */
function savePrefs(){
  const music = [...document.querySelectorAll("#musicChips .chip.active")].map(c=>c.dataset.value);
  const payload = {
    sleep: parseInt(document.getElementById("pSleepTime").value),
    wake: parseInt(document.getElementById("pWakeTime").value),
    clean: parseInt(document.getElementById("pClean").value),
    study: parseInt(document.getElementById("pStudy").value),
    budget: parseInt(document.getElementById("pBudget").value) || 0,
    social: parseInt(document.getElementById("pSocial").value),
    food: document.getElementById("pFood").value,
    lang: document.getElementById("pLang").value,
    smoke: document.getElementById("pSmoke").value,
    pets: document.getElementById("pPets").value,
    music
  };
  fetch("/api/preferences", {
    method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload)
  }).then(r=>r.json()).then(()=>{
    toast("Preferences saved 🌿");
    refreshCharts();
  });
}

/* ============================================================
   DAY SCHEDULE
   ============================================================ */
const SCHED_STATES = ["free","study","sleep","busy"];
function cycleCell(el){
  const cur = SCHED_STATES.findIndex(s=>el.classList.contains("sc-"+s));
  const next = SCHED_STATES[(cur+1) % SCHED_STATES.length];
  SCHED_STATES.forEach(s=>el.classList.remove("sc-"+s));
  el.classList.add("sc-"+next);
  el.textContent = next[0].toUpperCase();
}
function saveSchedule(){
  const days = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
  const schedule = {};
  days.forEach(d=>schedule[d] = ["","","",""]);
  document.querySelectorAll(".sched-cell").forEach(cell=>{
    const day = cell.dataset.day, block = parseInt(cell.dataset.block);
    const state = SCHED_STATES.find(s=>cell.classList.contains("sc-"+s));
    schedule[day][block] = state;
  });
  fetch("/api/schedule", {
    method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({schedule})
  }).then(r=>r.json()).then(()=>{
    toast("Schedule saved 🗓️");
    refreshCharts();
  });
}

/* ============================================================
   HOSTEL FINDER
   ============================================================ */
function renderHostels(){
  const params = new URLSearchParams({
    search: document.getElementById("hfSearch").value,
    budget: document.getElementById("hfBudget").value,
    gender: document.getElementById("hfGender").value,
    ac: document.getElementById("hfAc").value,
    wifi: document.getElementById("hfWifi").value
  });
  fetch("/api/hostels?" + params.toString()).then(r=>r.json()).then(list=>{
    const grid = document.getElementById("hostelGrid");
    grid.innerHTML = list.length ? "" : `<p style="color:var(--brown-soft);">No hostels match those filters yet — try widening your search.</p>`;
    list.forEach(h=>{
      const card = document.createElement("div");
      card.className = "hcard";
      card.innerHTML = `
        <div class="hcard-img">${h.emoji}</div>
        <div class="hcard-body">
          <h4>${h.name}</h4>
          <div class="hcard-price">₹${h.price.toLocaleString()}/mo</div>
          <div class="hcard-meta"><span>⭐ ${h.rating}</span><span>📍 ${h.distance} km</span><span>${h.ac}</span><span>📶 ${h.wifi}</span><span>${h.gender}</span></div>
          <div class="hcard-actions">
            <button class="btn btn-sm btn-ghost" onclick="toast('Saved to favorites ❤️')">Save</button>
            <button class="btn btn-sm btn-outline" onclick="toast('Added to comparison ⚖️')">Compare</button>
            <button class="btn btn-sm btn-primary" onclick="bookHostel('${h.name.replace(/'/g,"")}')">Book Now</button>
          </div>
        </div>`;
      grid.appendChild(card);
    });
    const map = document.getElementById("hostelMap");
    map.querySelectorAll(".map-pin").forEach(p=>p.remove());
    list.slice(0,8).forEach((h,i)=>{
      const pin = document.createElement("div");
      pin.className = "map-pin";
      pin.style.left = (12 + (i*11)%80) + "%";
      pin.style.top = (25 + (i*17)%55) + "%";
      pin.title = h.name;
      pin.textContent = "📍";
      map.appendChild(pin);
    });
  });
}
function bookHostel(name){
  fetch("/api/hostels/book", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({name})})
    .then(r=>r.json()).then(()=>{ toast(`Booked ${name} 🎉`); });
}

/* ============================================================
   ROOMMATE FINDER
   ============================================================ */
function renderRoommates(){
  fetch("/api/roommates").then(r=>r.json()).then(list=>{
    const grid = document.getElementById("roommateGrid");
    grid.innerHTML = "";
    list.forEach(r=>{
      const initials = r.name.split(" ").map(x=>x[0]).join("");
      const card = document.createElement("div");
      card.className = "rcard";
      card.innerHTML = `
        <div class="rcard-top">
          <div class="avatar">${initials}</div>
          <div><b>${r.name}</b><div style="font-size:0.72rem;color:var(--brown-soft);">${r.hobbies.slice(0,2).join(", ")}</div></div>
          <div class="rcard-score"><b>${r.score}%</b><small>match</small></div>
        </div>
        <div class="rcard-why">${r.reasons.map(x=>`<span>${x}</span>`).join("")}</div>
        <div class="rcard-actions">
          <button class="btn btn-sm btn-outline" onclick="openRadar(${r.id}, '${r.name.replace(/'/g,"")}')">📊 Radar</button>
          <button class="btn btn-sm btn-outline" onclick="openOverlap(${r.id}, '${r.name.replace(/'/g,"")}')">🗓️ Overlap</button>
          <button class="btn btn-sm btn-primary" onclick="matchRoommate('${r.name.replace(/'/g,"")}', ${r.score})">Connect</button>
        </div>`;
      grid.appendChild(card);
    });
  });
}
function matchRoommate(name, score){
  fetch("/api/roommates/connect", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({name, score})})
    .then(r=>r.json()).then(()=>{ toast(`Connected with ${name} 🤝`); });
}

/* radar / overlap modal — matplotlib images rendered server-side */
function openRadar(rid, name){
  document.getElementById("modalTitle").textContent = `You vs ${name}`;
  document.getElementById("overlapSummary").innerHTML = "";
  document.getElementById("modalImg").src = `/api/charts/radar/${rid}.png?v=${Date.now()}`;
  document.getElementById("matchModal").classList.add("open");
}
function openOverlap(rid, name){
  document.getElementById("modalTitle").textContent = `Schedule Overlap with ${name}`;
  document.getElementById("modalImg").src = `/api/charts/overlap/${rid}.png?v=${Date.now()}`;
  document.getElementById("matchModal").classList.add("open");
  fetch(`/api/schedule/overlap/${rid}`).then(r=>r.json()).then(res=>{
    const el = document.getElementById("overlapSummary");
    el.innerHTML = res.best_day
      ? `✨ You're both usually free on <b>${res.best_day} ${res.best_block}</b> — good time to plan a study session or hangout! (${res.total_overlap_blocks} overlapping blocks this week)`
      : "No strong overlap found yet — try adjusting your Day Schedule.";
  });
}
function closeModal(){ document.getElementById("matchModal").classList.remove("open"); }

/* ============================================================
   CHATBOT (HostBot)
   ============================================================ */
function addBotMsg(text){
  const body = document.getElementById("chatBody");
  const div = document.createElement("div");
  div.className = "msg bot";
  div.textContent = text;
  body.appendChild(div);
  body.scrollTop = body.scrollHeight;
}
function addUserMsg(text){
  const body = document.getElementById("chatBody");
  const div = document.createElement("div");
  div.className = "msg user";
  div.textContent = text;
  body.appendChild(div);
  body.scrollTop = body.scrollHeight;
}
function addSuggestion(label, tab){
  const body = document.getElementById("chatBody");
  const div = document.createElement("div");
  div.className = "msg suggest";
  const btn = document.createElement("button");
  btn.textContent = label;
  btn.onclick = ()=>{ switchTab(tab); toggleChat(); };
  div.appendChild(btn);
  body.appendChild(div);
  body.scrollTop = body.scrollHeight;
}
function toggleChat(){ document.getElementById("chatPanel").classList.toggle("open"); }
function sendChat(){
  const input = document.getElementById("chatInput");
  const text = input.value.trim();
  if(!text) return;
  addUserMsg(text);
  input.value = "";
  fetch("/api/chat", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({message:text})})
    .then(r=>r.json()).then(res=>{
      addBotMsg(res.reply);
      if(res.suggest_tab) addSuggestion(`Open ${res.suggest_tab.charAt(0).toUpperCase()+res.suggest_tab.slice(1)} Finder`, res.suggest_tab);
    });
}

/* ============================================================
   INIT
   ============================================================ */
document.addEventListener("DOMContentLoaded", ()=>{
  ["pSleepTime","pWakeTime","pClean","pStudy","pSocial"].forEach(id=>{
    const fmt = (id==="pSleepTime"||id==="pWakeTime") ? fmtHour : null;
    syncRange(id, id+"Val", fmt);
  });
  addBotMsg(`Hey ${USER_FIRST_NAME}! I'm HostBot 🏠 Ask me about hostels, roommates, budget, or bookings.`);
  renderHostels();
  renderRoommates();

  ["hfSearch","hfBudget","hfGender","hfAc","hfWifi"].forEach(id=>{
    document.getElementById(id).addEventListener("input", renderHostels);
    document.getElementById(id).addEventListener("change", renderHostels);
  });
});
